import React, { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Skills from "./components/Skills";
import Projects from "./components/Projects";
import Certifications from "./components/Certifications";
import Contact from "./components/Contact";
import TerminalWidget from "./components/TerminalWidget";
import ResumeModal from "./components/ResumeModal";
import { portfolioData } from "./data/portfolioData";
import { ChevronUp, Command, Cpu } from "lucide-react";

export default function App() {
  const [isResumeOpen, setIsResumeOpen] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleScrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  return (
    <div className="min-h-screen bg-white text-slate-800 font-sans selection:bg-brand-100 selection:text-brand-900 leading-normal">
      {/* Dynamic Navigation Sticky Header */}
      <Navbar
        ownerName={portfolioData.ownerName}
        onOpenResume={() => setIsResumeOpen(true)}
      />

      {/* Main Structural Layout Content */}
      <main id="portfolio-main-content">
        <Hero
          data={portfolioData}
          onOpenResume={() => setIsResumeOpen(true)}
        />
        
        <About data={portfolioData} />
        
        <Skills data={portfolioData} />
        
        <Projects data={portfolioData} />
        
        <Certifications data={portfolioData} />

        {/* Retro developer interface command-line utility */}
        <TerminalWidget
          data={portfolioData}
          onOpenResume={() => setIsResumeOpen(true)}
        />

        <Contact data={portfolioData} />
      </main>

      {/* Footer copyright segment */}
      <footer id="main-footer" className="bg-slate-50 border-t border-slate-100 py-12 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
          <div className="flex justify-center items-center space-x-2 text-slate-400">
            <Cpu className="w-4 h-4 text-brand-600 animate-pulse" />
            <span className="font-mono text-xs uppercase tracking-widest font-semibold">Guru R. Portfolio Platform</span>
          </div>

          <p className="font-sans text-xs sm:text-sm text-slate-500">
            &copy; {new Date().getFullYear()} {portfolioData.ownerName}. All Rights Reserved. Built with React, TypeScript, and Tailwind.
          </p>
          
          <div className="text-[10px] font-mono text-slate-400">
            Compilation: CSE Core Standard-78A • Handcrafted with love
          </div>
        </div>
      </footer>

      {/* A4 Printable CV Overlay portal */}
      <ResumeModal
        data={portfolioData}
        isOpen={isResumeOpen}
        onClose={() => setIsResumeOpen(false)}
      />

      {/* Floating Back To Top micro animation button */}
      {showScrollTop && (
        <button
          onClick={handleScrollToTop}
          className="fixed bottom-6 right-6 z-40 bg-brand-600 hover:bg-brand-700 text-white p-3 rounded-full transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105 active:scale-95 no-print border border-brand-500/10 cursor-pointer"
          aria-label="Back to top"
        >
          <ChevronUp className="w-5 h-5" />
        </button>
      )}
    </div>
  );
}
