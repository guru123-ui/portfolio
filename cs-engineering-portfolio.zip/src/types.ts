export interface ProjectDemoDetails {
  terminalLogs: string[];
  mockScreenHTML?: string;
  architectureDiagram?: string;
  codeSnippet?: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  technologies: string[];
  longDescription?: string;
  githubUrl?: string;
  liveUrl?: string;
  demoDetails?: ProjectDemoDetails;
}

export interface Skill {
  name: string;
  category: "Languages" | "Web Development" | "Databases & AI/ML";
  icon: string; // Name of Lucide icon
  level: number; // percentage eg 80, 90
  details: string; // where they used it or short note
}

export interface Certification {
  id: string;
  name: string;
  issuer: string;
  date: string;
  credentialId?: string;
  verifyUrl?: string;
  badgeColor?: string;
}

export interface Education {
  id: string;
  degree: string;
  institution: string;
  period: string;
  scoreName: string; // e.g. "GPA" or "Percentage"
  scoreValue: string; // e.g. "9.3/10" or "95%"
  highlights: string[];
}

export interface ContactInfo {
  email: string;
  phone: string;
  location: string;
  linkedin: string;
  github: string;
  twitter?: string;
}

export interface PortfolioData {
  ownerName: string;
  title: string;
  subtitle: string;
  introText: string;
  careerObjective: string;
  avatarUrl: string;
  education: Education[];
  skills: Skill[];
  projects: Project[];
  certifications: Certification[];
  contactInfo: ContactInfo;
}
