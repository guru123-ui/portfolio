import React, { useState } from "react";
import { Mail, Phone, MapPin, Send, Github, Linkedin, CheckCircle2, Trash2, Calendar } from "lucide-react";
import { PortfolioData } from "../types";

interface ContactProps {
  data: PortfolioData;
}

interface StoredMessage {
  id: string;
  name: string;
  email: string;
  message: string;
  timestamp: string;
}

export default function Contact({ data }: ContactProps) {
  // States for form inputs
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState({ name: "", email: "", message: "" });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  
  // Local session database of mock sent letters to make the app interactive and robust!
  const [sentMessages, setSentMessages] = useState<StoredMessage[]>(() => {
    try {
      const saved = localStorage.getItem("portfolio_sent_messages");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const validate = () => {
    let valid = true;
    const tempErrors = { name: "", email: "", message: "" };

    if (!formData.name.trim()) {
      tempErrors.name = "Full name is required";
      valid = false;
    }

    if (!formData.email.trim()) {
      tempErrors.email = "Email address is required";
      valid = false;
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      tempErrors.email = "Email format is invalid";
      valid = false;
    }

    if (!formData.message.trim()) {
      tempErrors.message = "Message cannot be empty";
      valid = false;
    }

    setErrors(tempErrors);
    return valid;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const handleSubmitMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);

    // Simulate database network timing delay
    setTimeout(() => {
      const newMessage: StoredMessage = {
        id: "msg-" + Date.now(),
        name: formData.name,
        email: formData.email,
        message: formData.message,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      const updatedMessages = [newMessage, ...sentMessages];
      setSentMessages(updatedMessages);
      localStorage.setItem("portfolio_sent_messages", JSON.stringify(updatedMessages));

      setIsSubmitting(false);
      setIsSuccess(true);
      setFormData({ name: "", email: "", message: "" });

      // Clear toast after a few seconds
      setTimeout(() => setIsSuccess(false), 5000);
    }, 1200);
  };

  const handleDeleteMessage = (id: string) => {
    const updated = sentMessages.filter((m) => m.id !== id);
    setSentMessages(updated);
    localStorage.setItem("portfolio_sent_messages", JSON.stringify(updated));
  };

  return (
    <section id="contact" className="py-20 bg-white border-t border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Get In Touch
          </h2>
          <div className="w-12 h-1 bg-brand-600 mx-auto mt-3 rounded-full" />
          <p className="mt-4 font-sans text-base text-slate-600">
            Have an open software role, a project proposal, or looking to collaborate? Drop a message below or contact me directly.
          </p>
        </div>

        {/* Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Details Panel (5 Columns) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-slate-50 border border-slate-100 p-6 sm:p-8 rounded-3xl shadow-sm space-y-8">
              <h3 className="font-display text-xl font-bold text-slate-800">
                Direct Coordinates
              </h3>

              {/* Coordinates List */}
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="p-3 bg-white text-brand-600 border border-slate-150 rounded-xl shadow-sm shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-xs font-mono text-slate-400 uppercase tracking-widest font-bold">Email Address</span>
                    <a
                      href={`mailto:${data.contactInfo.email}`}
                      className="text-slate-700 hover:text-brand-600 font-sans font-semibold text-sm sm:text-base break-all"
                    >
                      {data.contactInfo.email}
                    </a>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="p-3 bg-white text-brand-600 border border-slate-150 rounded-xl shadow-sm shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-xs font-mono text-slate-400 uppercase tracking-widest font-bold">Mobile Phone</span>
                    <a
                      href={`tel:${data.contactInfo.phone}`}
                      className="text-slate-700 hover:text-brand-600 font-sans font-semibold text-sm sm:text-base"
                    >
                      {data.contactInfo.phone}
                    </a>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="p-3 bg-white text-brand-600 border border-slate-150 rounded-xl shadow-sm shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-xs font-mono text-slate-400 uppercase tracking-widest font-bold">Location</span>
                    <span className="text-slate-700 font-sans font-semibold text-sm sm:text-base">
                      {data.contactInfo.location}
                    </span>
                  </div>
                </div>
              </div>

              {/* Social Channels panel */}
              <div className="pt-6 border-t border-slate-200/60">
                <span className="block text-xs font-mono text-slate-400 uppercase tracking-wider font-bold mb-4">
                  Professional Channels
                </span>
                <div className="flex items-center gap-3">
                  <a
                    href={data.contactInfo.github}
                    target="_blank"
                    rel="noreferrer"
                    referrerPolicy="no-referrer"
                    className="flex items-center space-x-2 bg-white hover:bg-brand-50 hover:text-brand-600 text-slate-700 border border-slate-200 hover:border-brand-300 px-4 py-2.5 rounded-xl text-xs font-bold shadow-sm transition-colors cursor-pointer"
                  >
                    <Github className="w-4 h-4" />
                    <span>GitHub</span>
                  </a>
                  <a
                    href={data.contactInfo.linkedin}
                    target="_blank"
                    rel="noreferrer"
                    referrerPolicy="no-referrer"
                    className="flex items-center space-x-2 bg-white hover:bg-brand-50 hover:text-brand-600 text-slate-700 border border-slate-200 hover:border-brand-300 px-4 py-2.5 rounded-xl text-xs font-bold shadow-sm transition-colors cursor-pointer"
                  >
                    <Linkedin className="w-4 h-4" />
                    <span>LinkedIn</span>
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Right Input Form (7 Columns) */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-white border border-slate-100 p-6 sm:p-8 rounded-3xl shadow-sm">
              <h3 className="font-display text-xl font-bold text-slate-850 mb-6">
                Send a Correspondence Letter
              </h3>

              {/* Action Form */}
              <form onSubmit={handleSubmitMessage} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name field */}
                  <div className="space-y-1 text-left">
                    <label htmlFor="name-input" className="block text-xs font-sans font-bold text-slate-750">
                      Your Full Name
                    </label>
                    <input
                      id="name-input"
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="e.g. Rachel Adams"
                      className={`w-full px-4 py-3 bg-slate-50 border rounded-xl text-sm font-sans focus:outline-none focus:bg-white text-slate-800 transition-all ${
                        errors.name ? "border-red-400 focus:ring-2 focus:ring-red-100" : "border-slate-200 focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500"
                      }`}
                    />
                    {errors.name && <span className="text-[11px] font-mono text-red-500">{errors.name}</span>}
                  </div>

                  {/* Email field */}
                  <div className="space-y-1 text-left">
                    <label htmlFor="email-input" className="block text-xs font-sans font-bold text-slate-750">
                      Email Address
                    </label>
                    <input
                      id="email-input"
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="e.g. rachel@work.com"
                      className={`w-full px-4 py-3 bg-slate-50 border rounded-xl text-sm font-sans focus:outline-none focus:bg-white text-slate-800 transition-all ${
                        errors.email ? "border-red-400 focus:ring-2 focus:ring-red-100" : "border-slate-200 focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500"
                      }`}
                    />
                    {errors.email && <span className="text-[11px] font-mono text-red-500">{errors.email}</span>}
                  </div>
                </div>

                {/* Message text element */}
                <div className="space-y-1 text-left">
                  <label htmlFor="message-input" className="block text-xs font-sans font-bold text-slate-750">
                    Your Message
                  </label>
                  <textarea
                    id="message-input"
                    name="message"
                    rows={4}
                    value={formData.message}
                    onChange={handleInputChange}
                    placeholder="Describe you query, job position, or proposal details..."
                    className={`w-full px-4 py-3 bg-slate-50 border rounded-xl text-sm font-sans focus:outline-none focus:bg-white text-slate-800 transition-all resize-none ${
                      errors.message ? "border-red-400 focus:ring-2 focus:ring-red-100" : "border-slate-200 focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500"
                    }`}
                  />
                  {errors.message && <span className="text-[11px] font-mono text-red-500">{errors.message}</span>}
                </div>

                {/* Submit Row Controls */}
                <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
                  
                  {/* Delivery Status */}
                  {isSuccess && (
                    <div className="flex items-center space-x-1.5 text-xs text-green-700 bg-green-50 border border-green-150 px-3 py-2 rounded-xl animate-scale-up font-semibold">
                      <CheckCircle2 className="w-4 h-4 text-green-600 shrink-0" />
                      <span>Message sent safely! Check session inbox below.</span>
                    </div>
                  )}

                  <div className="ml-auto">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className={`flex items-center space-x-2 bg-brand-600 hover:bg-brand-700 text-white font-sans font-bold px-5 py-3 rounded-xl transition-all shadow-md active:scale-95 text-xs sm:text-sm cursor-pointer ${
                        isSubmitting ? "opacity-70 cursor-wait" : ""
                      }`}
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-4 h-4 rounded-full border-2 border-white/40 border-t-white animate-spin" />
                          <span>Routing packet...</span>
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4" />
                          <span>Send Message</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

              </form>
            </div>

            {/* Simulated Live Inbox for Testing Forms */}
            {sentMessages.length > 0 && (
              <div className="bg-slate-50 border border-slate-150 rounded-3xl p-6 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <h4 className="font-display font-extrabold text-sm text-slate-850 flex items-center space-x-1.5">
                      <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                      <span>Local Sandbox Outbox Logging</span>
                    </h4>
                    <p className="text-[10px] font-mono text-slate-400">
                      Messages stored temporarily in your local browser storage for testing.
                    </p>
                  </div>
                  
                  <button
                    onClick={() => {
                      setSentMessages([]);
                      localStorage.removeItem("portfolio_sent_messages");
                    }}
                    className="p-1.5 hover:bg-red-50 text-slate-400 hover:text-red-550 border border-slate-200 hover:border-red-100 rounded-lg transition-colors text-xs flex items-center space-x-1 font-sans"
                    title="Clear database"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline font-semibold">Empty</span>
                  </button>
                </div>

                <div className="space-y-3 max-h-[220px] overflow-y-auto">
                  {sentMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className="bg-white border border-slate-100 rounded-xl p-4 shadow-sm flex items-start justify-between gap-4 animate-scale-up"
                    >
                      <div className="space-y-2 text-left w-full overflow-hidden">
                        <div className="flex flex-wrap items-center justify-between gap-1 border-b border-slate-50 pb-1.5">
                          <span className="text-xs font-bold text-slate-800 tracking-tight truncate">
                            {msg.name} (<span className="text-brand-600 font-medium">{msg.email}</span>)
                          </span>
                          <span className="text-[10px] font-mono text-slate-400">
                            Sent at {msg.timestamp}
                          </span>
                        </div>
                        <p className="font-sans text-xs text-slate-600 leading-relaxed break-words whitespace-pre-line">
                          {msg.message}
                        </p>
                      </div>

                      <button
                        onClick={() => handleDeleteMessage(msg.id)}
                        className="text-slate-350 hover:text-red-500 p-1 rounded-md hover:bg-slate-50 transition-colors shrink-0"
                        title="Delete receipt"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>

        </div>

      </div>
    </section>
  );
}
