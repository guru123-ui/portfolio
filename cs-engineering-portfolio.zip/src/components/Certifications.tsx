import React from "react";
import { Award, ExternalLink, ShieldCheck, Calendar, Bookmark } from "lucide-react";
import { PortfolioData } from "../types";

interface CertificationsProps {
  data: PortfolioData;
}

export default function Certifications({ data }: CertificationsProps) {
  return (
    <section id="certifications" className="py-20 bg-slate-50 border-t border-slate-100 tech-grid-dots">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Certifications & Medals
          </h2>
          <div className="w-12 h-1 bg-brand-600 mx-auto mt-3 rounded-full" />
          <p className="mt-4 font-sans text-base text-slate-600">
            A selective collection of certified professional specializations, academic medals, and technical credentials.
          </p>
        </div>

        {/* Certifications Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {data.certifications.map((cert) => (
            <div
              key={cert.id}
              className="bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md hover:-translate-y-1 transition-all duration-300 p-6 flex flex-col justify-between relative overflow-hidden group"
            >
              {/* Abs decorative background overlay */}
              <div className="absolute top-0 right-0 p-3 text-slate-100 group-hover:text-brand-50 transition-colors pointer-events-none">
                <Award className="w-10 h-10 stroke-[1.5]" />
              </div>

              {/* Top body info */}
              <div className="space-y-4">
                {/* Colored Label Badge */}
                <div className={`px-2.5 py-1 text-[10px] font-bold font-mono tracking-wider rounded-lg border inline-block ${cert.badgeColor || "bg-brand-50 border-brand-100 text-brand-700"}`}>
                  {cert.issuer}
                </div>

                {/* Name */}
                <h3 className="font-display font-extrabold text-slate-900 text-sm sm:text-base leading-snug group-hover:text-brand-600 transition-colors">
                  {cert.name}
                </h3>
                
                {/* Meta details */}
                <div className="space-y-1.5 pt-2 font-sans text-xs text-slate-500">
                  <div className="flex items-center space-x-1.5">
                    <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>Certified: <b>{cert.date}</b></span>
                  </div>
                  {cert.credentialId && (
                    <div className="flex items-center space-x-1.5 font-mono text-[10px] text-slate-400 bg-slate-50 px-2 py-1 rounded-md border border-slate-150 w-full truncate">
                      <Bookmark className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">ID: <b>{cert.credentialId}</b></span>
                    </div>
                  )}
                </div>
              </div>

              {/* Bottom anchor footer */}
              <div className="pt-6 mt-6 border-t border-slate-50 flex items-center justify-between text-xs">
                <div className="flex items-center space-x-1 text-slate-600">
                  <ShieldCheck className="w-4 h-4 text-green-500 shrink-0" />
                  <span className="font-sans font-medium text-slate-500">Verified Badge</span>
                </div>

                {cert.verifyUrl && (
                  <a
                    href={cert.verifyUrl}
                    target="_blank"
                    rel="noreferrer"
                    referrerPolicy="no-referrer"
                    className="flex items-center space-x-1 text-brand-600 hover:text-brand-800 hover:underline font-bold font-sans transition-all cursor-pointer"
                  >
                    <span>Verify</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
