import React from "react";
import { ArrowRight, Terminal, GraduationCap, Github, Linkedin, Sparkles, Server, FileText } from "lucide-react";
import { PortfolioData } from "../types";

interface HeroProps {
  data: PortfolioData;
  onOpenResume: () => void;
}

export default function Hero({ data, onOpenResume }: HeroProps) {
  const handleScrollToContact = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    const contactSection = document.getElementById("contact");
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center pt-24 pb-16 bg-gradient-to-br from-brand-50/50 via-white to-white overflow-hidden tech-grid"
    >
      {/* Absolute decorative floating background circles */}
      <div className="absolute top-20 right-[-10%] w-[500px] h-[500px] bg-brand-200/20 rounded-full filter blur-3xl opacity-60 pointer-events-none" />
      <div className="absolute bottom-10 left-[-5%] w-[350px] h-[350px] bg-brand-100/35 rounded-full filter blur-2xl opacity-60 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Main Content Columns (Left side on large screens) */}
          <div className="lg:col-span-7 text-left space-y-6">
            
            {/* Soft badge */}
            <div className="inline-flex items-center space-x-2 px-3 py-1 bg-brand-100/80 border border-brand-200/55 rounded-full text-brand-700 text-xs font-semibold tracking-wide uppercase font-sans animate-fade-in">
              <Sparkles className="w-3.5 h-3.5 text-brand-600 animate-pulse" />
              <span>Seeking Opportunities • B.E. CS Student</span>
            </div>

            {/* Main Headline */}
            <div className="space-y-2">
              <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.1]">
                Hi, I'm <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-600 to-brand-800">{data.ownerName}</span>
              </h1>
              <p className="font-display text-xl sm:text-2xl font-bold text-slate-700">
                {data.title}
              </p>
            </div>

            {/* Brief Bio */}
            <p className="font-sans text-base sm:text-lg text-slate-600 max-w-xl leading-relaxed">
              {data.introText}
            </p>

            {/* Quick CSE Credentials list */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 py-2">
              <div className="flex items-center space-x-2 text-slate-700">
                <GraduationCap className="w-5 h-5 text-brand-600 shrink-0" />
                <span className="text-xs font-semibold font-mono">PSG Tech BE CS</span>
              </div>
              <div className="flex items-center space-x-2 text-slate-700">
                <Server className="w-5 h-5 text-brand-600 shrink-0" />
                <span className="text-xs font-semibold font-mono">Full-Stack & ML</span>
              </div>
              <div className="flex items-center space-x-2 text-slate-700">
                <Terminal className="w-5 h-5 text-brand-600 shrink-0" />
                <span className="text-xs font-semibold font-mono">GPA: 9.34/10.0</span>
              </div>
            </div>

            {/* Call To Actions */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              <button
                onClick={onOpenResume}
                className="flex items-center justify-center space-x-2 bg-brand-600 hover:bg-brand-700 text-white font-sans font-semibold px-6 py-3.5 rounded-xl transition-all shadow-md hover:shadow-lg focus:ring-4 focus:ring-brand-500/20 active:scale-[0.98]"
              >
                <FileText className="w-5 h-5" />
                <span>View & Print Resume</span>
              </button>

              <button
                onClick={handleScrollToContact}
                className="flex items-center justify-center space-x-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 hover:border-slate-300 font-sans font-semibold px-6 py-3.5 rounded-xl transition-all shadow-sm focus:ring-4 focus:ring-slate-100 active:scale-[0.98]"
              >
                <span>Get In Touch</span>
                <ArrowRight className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            {/* Social Anchor Links */}
            <div className="flex items-center space-x-4 pt-4">
              <a
                href={data.contactInfo.github}
                target="_blank"
                rel="noreferrer"
                referrerPolicy="no-referrer"
                className="p-2.5 bg-slate-150 rounded-xl hover:bg-brand-50 hover:text-brand-600 text-slate-600 transition-colors shadow-sm"
                title="GitHub Profile"
              >
                <Github className="w-5 h-5" />
              </a>
              <a
                href={data.contactInfo.linkedin}
                target="_blank"
                rel="noreferrer"
                referrerPolicy="no-referrer"
                className="p-2.5 bg-slate-150 rounded-xl hover:bg-brand-50 hover:text-brand-600 text-slate-600 transition-colors shadow-sm"
                title="LinkedIn Network"
              >
                <Linkedin className="w-5 h-5" />
              </a>
            </div>

          </div>

          {/* Profile Photo Placeholder & Tech Showcase (Right side) */}
          <div className="lg:col-span-5 flex justify-center items-center">
            <div className="relative">
              
              {/* Spinning background circle tags */}
              <div className="absolute -inset-4 rounded-full border-2 border-dashed border-brand-300/60 animate-[spin_50s_linear_infinite]" />
              <div className="absolute -inset-8 rounded-full border border-dotted border-brand-200/40 animate-[spin_30s_linear_infinite_reverse]" />

              {/* Glowing ring */}
              <div className="absolute -inset-1 rounded-full bg-gradient-to-tr from-brand-400 via-brand-600 to-brand-800 filter blur-sm opacity-35" />

              {/* Photo Box container */}
              <div className="relative w-64 h-64 sm:w-72 sm:h-72 rounded-full overflow-hidden bg-white p-2 shadow-xl border border-slate-100">
                <img
                  src={data.avatarUrl}
                  alt={data.ownerName}
                  className="w-full h-full object-cover rounded-full"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    // Fallback to beautiful profile card if image breaks
                    const img = e.currentTarget;
                    img.style.display = "none";
                    const parent = img.parentElement;
                    if (parent) {
                      const fallback = document.createElement("div");
                      fallback.className = "w-full h-full rounded-full bg-gradient-to-br from-brand-600 to-brand-800 flex flex-col justify-center items-center text-white";
                      fallback.innerHTML = `
                        <span class="text-5xl font-display font-extrabold tracking-wider">GP</span>
                        <span class="text-[10px] font-mono mt-2 tracking-widest text-brand-200">PORTFOLIO</span>
                      `;
                      parent.appendChild(fallback);
                    }
                  }}
                />
              </div>

              {/* Hover Floating Mini Terminal Badge */}
              <div className="absolute -bottom-3 -right-3 sm:-right-6 bg-slate-900 border border-slate-800 text-brand-400 px-3.5 py-2 rounded-xl shadow-lg flex items-center space-x-2 font-mono text-[11px] select-none hover:scale-105 transition-transform duration-300">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-ping" />
                <span>active_processes = 47</span>
              </div>
              
              {/* Additional small decoration */}
              <div className="absolute -top-3 -left-3 sm:-left-6 bg-white border border-slate-100 text-slate-800 px-3 py-1.5 rounded-lg shadow-md flex items-center space-x-1.5 font-mono text-[10px] uppercase font-bold tracking-wide">
                <span>⚡ code++</span>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
