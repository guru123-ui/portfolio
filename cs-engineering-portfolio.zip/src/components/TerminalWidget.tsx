import React, { useState, useRef, useEffect } from "react";
import { Terminal, CornerDownLeft, Sparkles } from "lucide-react";
import { PortfolioData } from "../types";

interface TerminalWidgetProps {
  data: PortfolioData;
  onOpenResume: () => void;
}

interface CommandHistory {
  input: string;
  output: string[];
}

export default function TerminalWidget({ data, onOpenResume }: TerminalWidgetProps) {
  const [inputVal, setInputVal] = useState("");
  const [history, setHistory] = useState<CommandHistory[]>([
    {
      input: "system_init",
      output: [
        "==================================================",
        " GURU-PRASATH-OS v1.7.2 [Vite-TypeScript-React]   ",
        " System initialization complete over port: 3000   ",
        " Type 'help' and press [Enter] to display commands ",
        "=================================================="
      ]
    }
  ]);

  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [history]);

  const handleTerminalFocus = () => {
    inputRef.current?.focus();
  };

  const handleCommandRun = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanInput = inputVal.trim().toLowerCase();
    if (!cleanInput) return;

    let output: string[] = [];

    switch (cleanInput) {
      case "help":
        output = [
          "Available Commands:",
          "  about       - Display career objective and schools",
          "  skills      - List high-proficiency development stacks",
          "  projects    - List academic & personal project indexes",
          "  contact     - Print email, linkedin, and coordinate maps",
          "  resume      - Trigger printing of professional CV document",
          "  clear       - Wipe terminal cache history lines"
        ];
        break;

      case "about":
        output = [
          "🎓 CAREER OBJECTIVE:",
          `  ${data.careerObjective}`,
          "",
          "🏫 ACADEMICS TIMELINES:",
          ...data.education.map(edu => `  • ${edu.degree} @ ${edu.institution} (${edu.period}) -> CGPA: ${edu.scoreValue}`)
        ];
        break;

      case "skills":
        output = [
          "🛠️ CORE DEVELOPMENT COGNITION STACK:",
          "  [Languages]       : C, C++, Java, Python",
          "  [Web Coding]      : HTML, CSS, JavaScript, React, TypeScript, Tailwind",
          "  [Databases & AI]  : SQL, PostgreSQL, PyTorch, Artificial Intelligence, ML Pipelines",
          "",
          "*(Click on cards in the 'Skills' section above to inspect detailed capabilities.)"
        ];
        break;

      case "projects":
        output = [
          "💻 ACTIVE CODING WORKSPACES:",
          ...data.projects.map(p => `  • ${p.title}: ${p.description} [${p.technologies.join(", ")}]`)
        ];
        break;

      case "contact":
        output = [
          "📬 CONTACT MATRIX COORDINATES:",
          `  • Email    : ${data.contactInfo.email}`,
          `  • Phone    : ${data.contactInfo.phone}`,
          `  • Location : ${data.contactInfo.location}`,
          `  • GitHub   : ${data.contactInfo.github}`,
          `  • LinkedIn : ${data.contactInfo.linkedin}`
        ];
        break;

      case "resume":
        output = ["Initializing PDF Print module... [SUCCESS]", "Opening printing layer overlay..."];
        setTimeout(() => onOpenResume(), 100);
        break;

      case "clear":
        setHistory([]);
        setInputVal("");
        return;

      default:
        output = [
          `bash: command not found: '${cleanInput}'`,
          "Type 'help' to audit allowed system commands."
        ];
        break;
    }

    setHistory((prev) => [...prev, { input: inputVal, output }]);
    setInputVal("");
  };

  return (
    <section className="py-12 bg-white border-t border-slate-100 no-print">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Widget Label */}
        <div className="flex items-center space-x-2 text-slate-500 font-mono text-xs uppercase mb-4 justify-center">
          <Terminal className="w-4 h-4 text-brand-650" />
          <span>Interactive CSE Terminal CLI Playground</span>
          <Sparkles className="w-3.5 h-3.5 text-yellow-500 animate-pulse" />
        </div>

        {/* Terminal Container */}
        <div
          onClick={handleTerminalFocus}
          className="bg-slate-950 border border-slate-900 rounded-2xl shadow-xl p-5 mx-auto font-mono text-xs text-left h-72 sm:h-80 overflow-y-auto flex flex-col justify-between cursor-text text-white relative hover:ring-2 hover:ring-brand-500/25 transition-all duration-300"
        >
          {/* Header dots */}
          <div className="absolute top-4 right-4 flex items-center space-x-1.5 select-none opacity-60">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-800" />
            <span className="w-2.5 h-2.5 rounded-full bg-slate-800" />
            <span className="w-2.5 h-2.5 rounded-full bg-slate-800" />
          </div>

          <div className="space-y-4 overflow-y-auto pr-2 max-h-[calc(100%-40px)]">
            {history.map((hist, index) => (
              <div key={index} className="space-y-1">
                <div className="flex items-center space-x-1.5 text-green-400">
                  <span className="text-slate-500">guest@guru-prasath-portfolio:~$</span>
                  <span className="font-semibold">{hist.input}</span>
                </div>
                <div className="text-slate-300 pl-4 space-y-0.5 leading-relaxed whitespace-pre-wrap">
                  {hist.output.map((line, lineIdx) => (
                    <div key={lineIdx}>{line}</div>
                  ))}
                </div>
              </div>
            ))}
            <div ref={bottomRef} />
          </div>

          {/* Prompt input Form */}
          <form onSubmit={handleCommandRun} className="flex items-center space-x-1 border-t border-slate-900 pt-3 mt-4">
            <span className="text-brand-400 select-none font-bold shrink-0">guest@portfolio:~$</span>
            <input
              id="terminal-cli-input"
              ref={inputRef}
              type="text"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder="e.g. skills, about, projects, resume..."
              className="w-full bg-transparent border-none text-brand-300 focus:outline-none focus:ring-0 placeholder-slate-700 font-mono text-xs pl-1"
              autoComplete="off"
            />
            <button
              type="submit"
              className="text-slate-650 hover:text-white transition-colors"
              aria-label="Submit CLI"
            >
              <CornerDownLeft className="w-3.5 h-3.5" />
            </button>
          </form>

        </div>

      </div>
    </section>
  );
}
