import React, { useState, useEffect } from "react";
import { Terminal, Github, ExternalLink, Cpu, Play, Code, Info, CheckCircle2, ChevronRight, X, Copy, Check } from "lucide-react";
import { PortfolioData, Project } from "../types";

interface ProjectsProps {
  data: PortfolioData;
}

export default function Projects({ data }: ProjectsProps) {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [activeTab, setActiveTab] = useState<"overview" | "terminal" | "code">("overview");
  const [terminalOutput, setTerminalOutput] = useState<string[]>([]);
  const [logsRunning, setLogsRunning] = useState(false);
  const [copied, setCopied] = useState(false);

  // Trigger terminal logs simulation line by line is incredibly immersive!
  useEffect(() => {
    if (selectedProject?.demoDetails?.terminalLogs && activeTab === "terminal") {
      setTerminalOutput([]);
      setLogsRunning(true);
      const logs = selectedProject.demoDetails.terminalLogs;
      let index = 0;

      const interval = setInterval(() => {
        if (index < logs.length) {
          setTerminalOutput((prev) => [...prev, logs[index]]);
          index++;
        } else {
          setLogsRunning(false);
          clearInterval(interval);
        }
      }, 550);

      return () => clearInterval(interval);
    }
  }, [selectedProject, activeTab]);

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section id="projects" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Featured Projects
          </h2>
          <div className="w-12 h-1 bg-brand-600 mx-auto mt-3 rounded-full" />
          <p className="mt-4 font-sans text-base text-slate-600">
            A deep-dive showcase into engineering challenges I've solved. Click <b className="text-brand-600">"View Dev Sandbox"</b> on any project card to inspect code files and live system execution.
          </p>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
          {data.projects.map((project) => (
            <div
              key={project.id}
              className="group bg-white rounded-2xl border border-slate-100 hover:border-brand-300 shadow-sm hover:shadow-md transition-all duration-300 flex flex-col justify-between overflow-hidden relative"
            >
              {/* Highlight top-bar decorations */}
              <div className="h-1.5 w-full bg-gradient-to-r from-brand-500 to-brand-800 opacity-80" />

              {/* Card Body */}
              <div className="p-6 sm:p-8 space-y-6 flex-grow">
                {/* Header title */}
                <div className="space-y-2">
                  <h3 className="font-display text-xl font-bold text-slate-800 group-hover:text-brand-600 transition-colors">
                    {project.title}
                  </h3>
                  <div className="flex flex-wrap gap-1.5">
                    {project.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="px-2.5 py-0.5 bg-brand-50 text-brand-700 text-[10px] font-bold font-mono rounded-md border border-brand-100/60"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Description */}
                <p className="font-sans text-sm text-slate-600 leading-relaxed">
                  {project.description}
                </p>
              </div>

              {/* Action Toolbar footer */}
              <div className="px-6 py-5 bg-slate-50 border-t border-slate-100/80 flex flex-wrap items-center justify-between gap-4">
                <button
                  onClick={() => {
                    setSelectedProject(project);
                    setActiveTab("overview");
                  }}
                  className="flex items-center space-x-2 bg-white hover:bg-brand-50 text-slate-800 hover:text-brand-700 border border-slate-200 hover:border-brand-300/60 px-4 py-2.5 rounded-xl text-xs font-bold shadow-sm transition-all active:scale-[0.98]"
                >
                  <Terminal className="w-4 h-4 text-brand-600" />
                  <span>View Dev Sandbox</span>
                </button>

                <div className="flex items-center space-x-3 text-slate-500">
                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noreferrer"
                    referrerPolicy="no-referrer"
                    className="p-2 hover:text-brand-600 hover:bg-slate-200/50 rounded-lg transition-colors cursor-pointer"
                    title="Source Code"
                  >
                    <Github className="w-4.5 h-4.5" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Dynamic Project Inspector Sandbox Overlay Modal */}
        {selectedProject && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 no-print">
            
            {/* Backdrop filter blur */}
            <div
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity"
              onClick={() => setSelectedProject(null)}
            />

            {/* Modal Body Container */}
            <div className="relative bg-white rounded-3xl w-full max-w-4xl max-h-[85vh] overflow-hidden shadow-2xl border border-slate-100 flex flex-col z-10 animate-scale-up">
              
              {/* Header Box */}
              <div className="flex items-center justify-between p-6 border-b border-slate-100 bg-slate-50">
                <div className="space-y-1">
                  <div className="text-[10px] uppercase tracking-wider font-bold text-brand-600 bg-brand-50 border border-brand-100 px-2 py-0.5 rounded-md inline-block">
                    Project Sandbox Inspector
                  </div>
                  <h3 className="font-display text-xl sm:text-2xl font-extrabold text-slate-900">
                    {selectedProject.title}
                  </h3>
                </div>
                
                {/* Close anchor button */}
                <button
                  onClick={() => setSelectedProject(null)}
                  className="p-2 text-slate-400 hover:bg-slate-200/60 text-slate-600 rounded-full transition-colors"
                  aria-label="Close Sandbox"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Tabs Navigator and Toolbar */}
              <div className="flex border-b border-slate-100 bg-white px-6 py-2 overflow-x-auto gap-2">
                <button
                  onClick={() => setActiveTab("overview")}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-xs font-semibold font-sans transition-all shrink-0 ${
                    activeTab === "overview"
                      ? "bg-brand-50 text-brand-700"
                      : "text-slate-500 hover:bg-slate-50"
                  }`}
                >
                  <Info className="w-3.5 h-3.5" />
                  <span>Architecture & Bio</span>
                </button>

                <button
                  onClick={() => setActiveTab("terminal")}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-xs font-semibold font-sans transition-all shrink-0 ${
                    activeTab === "terminal"
                      ? "bg-slate-900 text-green-400"
                      : "text-slate-500 hover:bg-slate-50"
                  }`}
                >
                  <Terminal className="w-3.5 h-3.5" />
                  <span>Interactive System Logs</span>
                </button>

                <button
                  onClick={() => setActiveTab("code")}
                  className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-xs font-semibold font-sans transition-all shrink-0 ${
                    activeTab === "code"
                      ? "bg-slate-900 text-brand-300"
                      : "text-slate-500 hover:bg-slate-50"
                  }`}
                >
                  <Code className="w-3.5 h-3.5" />
                  <span>Core Logic Files</span>
                </button>
              </div>

              {/* Dynamic Scrolling Tab Content Area */}
              <div className="flex-grow p-6 overflow-y-auto max-h-[50vh] bg-slate-50/50">
                
                {/* 1. OVERVIEW WRAPPER */}
                {activeTab === "overview" && (
                  <div className="space-y-6">
                    <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm space-y-4">
                      <h4 className="font-display font-bold text-slate-800 text-lg flex items-center gap-2">
                        <CheckCircle2 className="w-5 h-5 text-brand-600" />
                        <span>Executive Architecture Summary</span>
                      </h4>
                      <p className="font-sans text-slate-600 text-sm leading-relaxed whitespace-pre-line">
                        {selectedProject.longDescription || selectedProject.description}
                      </p>
                    </div>

                    <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm">
                      <h4 className="font-display font-semibold text-slate-800 text-sm mb-3">
                        Target System Technologies Stacked
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedProject.technologies.map((tech) => (
                          <span
                            key={tech}
                            className="px-3.5 py-1.5 bg-slate-50 border border-slate-200/60 rounded-xl text-xs font-bold text-slate-700 font-mono"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* 2. TERM EXECUTION LOGGER */}
                {activeTab === "terminal" && selectedProject.demoDetails && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono text-slate-500">System Pipeline Streams:</span>
                      <button
                        onClick={() => {
                          setTerminalOutput([]);
                          setLogsRunning(true);
                          // trigger rebuild
                          const logs = selectedProject.demoDetails?.terminalLogs || [];
                          let index = 0;
                          const t = setInterval(() => {
                            if (index < logs.length) {
                              setTerminalOutput((prev) => idx => index === 0 ? [logs[0]] : [...prev, logs[index]]);
                              index++;
                            } else {
                              setLogsRunning(false);
                              clearInterval(t);
                            }
                          }, 550);
                        }}
                        disabled={logsRunning}
                        className={`text-xs px-3 py-1 font-mono rounded border flex items-center space-x-1.5 ${
                          logsRunning
                            ? "bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed"
                            : "bg-white hover:bg-slate-100 border-slate-200 cursor-pointer text-slate-700"
                        }`}
                      >
                        <Play className="w-3 h-3 text-green-600" />
                        <span>Re-run Diagnostics</span>
                      </button>
                    </div>

                    <div className="bg-slate-950 border border-slate-900 rounded-2xl p-6 font-mono text-xs text-slate-200 min-h-[250px] shadow-lg flex flex-col justify-between">
                      <div className="space-y-1.5 max-h-[180px] overflow-y-auto">
                        {terminalOutput.map((log, lIdx) => {
                          const isWarning = log.toLowerCase().includes("warn");
                          const isError = log.toLowerCase().includes("err") || log.toLowerCase().includes("fail");
                          const isSuccess = log.toLowerCase().includes("ok") || log.toLowerCase().includes("success") || log.toLowerCase().includes("complete");

                          let colorClass = "text-white";
                          if (isWarning) colorClass = "text-yellow-400";
                          if (isError) colorClass = "text-red-400";
                          if (isSuccess) colorClass = "text-green-400 font-bold";

                          return (
                            <div key={lIdx} className={`flex items-start ${colorClass} leading-relaxed`}>
                              <span className="text-slate-500 select-none mr-2 font-semibold">[{lIdx + 1}]</span>
                              <span className="whitespace-pre-wrap">{log}</span>
                            </div>
                          );
                        })}
                      </div>

                      {logsRunning && (
                        <div className="flex items-center space-x-2 text-slate-400 mt-4 pt-4 border-t border-slate-900">
                          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                          <span className="animate-pulse">Synthesizing network cycles... please wait...</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* 3. CORE LOGIC SNIPPET */}
                {activeTab === "code" && selectedProject.demoDetails && (
                  <div className="space-y-4">
                    <div className="flex justify-between items-center px-1">
                      <span className="text-xs font-mono text-slate-500">
                        {selectedProject.title.replace(/\s+/g, "_").toLowerCase()}_core.cpp
                      </span>
                      <button
                        onClick={() => handleCopyCode(selectedProject.demoDetails?.codeSnippet || "")}
                        className="flex items-center space-x-1.5 text-xs text-brand-600 hover:text-brand-800 font-sans font-bold bg-white px-2.5 py-1 rounded border border-slate-200 hover:border-brand-300 transition-all shadow-sm"
                      >
                        {copied ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-green-600" />
                            <span>Copied!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy File</span>
                          </>
                        )}
                      </button>
                    </div>

                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 overflow-x-auto shadow-inner text-white text-xs max-h-[300px] overflow-y-auto">
                      <pre className="font-mono text-left leading-relaxed">
                        <code>{selectedProject.demoDetails.codeSnippet}</code>
                      </pre>
                    </div>
                  </div>
                )}

              </div>

              {/* Modal Footer Controls */}
              <div className="p-6 border-t border-slate-100 bg-white flex justify-end gap-3">
                <button
                  onClick={() => setSelectedProject(null)}
                  className="bg-slate-100 hover:bg-slate-200/80 text-slate-700 px-5 py-2.5 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                >
                  Close Inspector
                </button>
                <a
                  href={selectedProject.githubUrl}
                  target="_blank"
                  rel="noreferrer"
                  referrerPolicy="no-referrer"
                  className="bg-brand-600 hover:bg-brand-700 text-white px-5 py-2.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-colors shadow-sm"
                >
                  <Github className="w-4 h-4" />
                  <span>Inspect Repo Source</span>
                </a>
              </div>

            </div>
          </div>
        )}

      </div>
    </section>
  );
}
