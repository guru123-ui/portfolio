import React, { useRef } from "react";
import { X, Printer, Download, Mail, Phone, MapPin, Github, Linkedin, Award, FileText } from "lucide-react";
import { PortfolioData } from "../types";

interface ResumeModalProps {
  data: PortfolioData;
  isOpen: boolean;
  onClose: () => void;
}

export default function ResumeModal({ data, isOpen, onClose }: ResumeModalProps) {
  if (!isOpen) return null;

  const handlePrint = (e: React.FormEvent) => {
    e.preventDefault();
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 sm:p-4 md:p-6 overflow-y-auto no-print">
      
      {/* Dark blur backdrop */}
      <div
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* CV Sheet Wrapper */}
      <div className="relative bg-slate-50 w-full max-w-4xl min-h-screen sm:min-h-0 sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col z-10 animate-scale-up max-h-[100vh] sm:max-h-[90vh]">
        
        {/* Printable Control Toolbar Header (Excluded in standard prints via CSS) */}
        <div className="no-print bg-white px-6 py-4 border-b border-slate-200/60 sticky top-0 z-20 flex items-center justify-between shadow-sm">
          <div className="flex items-center space-x-2 text-slate-800">
            <FileText className="w-5 h-5 text-brand-600" />
            <span className="font-display font-extrabold text-sm sm:text-base">Professional Academic CV</span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="flex items-center space-x-1.5 bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold font-sans px-4 py-2.5 rounded-xl transition-all shadow-sm cursor-pointer hover:shadow-md"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print or Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-slate-100 text-slate-400 hover:text-slate-700 rounded-full transition-colors cursor-pointer"
              aria-label="Close CV viewer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable A4 CV Container */}
        <div id="cv-print-area" className="flex-grow p-6 sm:p-10 md:p-12 bg-white overflow-y-auto text-left select-text print:p-0">
          
          {/* CV GRID */}
          <div className="max-w-[800px] mx-auto space-y-8">
            
            {/* 1. PRIMARY CONTACT BANNER */}
            <div className="border-b-2 border-slate-900 pb-5 text-center sm:text-left flex flex-col sm:flex-row justify-between items-center sm:items-end gap-4">
              <div className="space-y-1">
                <h1 className="font-display font-extrabold text-3xl text-slate-900 tracking-tight">
                  {data.ownerName}
                </h1>
                <p className="font-display text-brand-700 font-bold text-sm uppercase tracking-wide">
                  {data.title}
                </p>
              </div>

              {/* Coordinates block */}
              <div className="text-right font-mono text-[11px] text-slate-500 space-y-1">
                <div className="flex items-center justify-center sm:justify-end gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <a href={`mailto:${data.contactInfo.email}`} className="hover:underline">{data.contactInfo.email}</a>
                </div>
                <div className="flex items-center justify-center sm:justify-end gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>{data.contactInfo.phone}</span>
                </div>
                <div className="flex items-center justify-center sm:justify-end gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>{data.contactInfo.location}</span>
                </div>
                <div className="flex items-center justify-center sm:justify-end gap-1.5 pt-1">
                  <span className="font-semibold text-slate-800">GitHub:</span>
                  <a href={data.contactInfo.github} target="_blank" rel="noreferrer" className="hover:underline text-brand-600 truncate">{data.contactInfo.github}</a>
                </div>
              </div>
            </div>

            {/* 2. CAREER EXECUTIVE SUMMARY */}
            <div className="space-y-2">
              <h3 className="font-display font-extrabold text-sm uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1 flex items-center justify-between">
                <span>Education Objectives</span>
              </h3>
              <p className="font-sans text-xs sm:text-sm text-slate-600 leading-relaxed">
                {data.careerObjective}
              </p>
            </div>

            {/* 3. DETAILED EDUCATION TIMELINE */}
            <div className="space-y-3">
              <h3 className="font-display font-extrabold text-sm uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1">
                Academic Background
              </h3>
              
              <div className="space-y-4">
                {data.education.map((edu) => (
                  <div key={edu.id} className="flex flex-col sm:flex-row justify-between items-start gap-1">
                    <div className="space-y-1.5 flex-grow">
                      <div className="flex flex-wrap items-center gap-x-2">
                        <span className="font-display font-bold text-slate-850 text-sm">
                          {edu.degree}
                        </span>
                        <span className="text-[11px] font-bold text-slate-400 hidden sm:inline">|</span>
                        <span className="font-sans font-semibold text-slate-650 text-xs text-brand-700">
                          {edu.institution}
                        </span>
                      </div>
                      
                      <ul className="list-disc pl-4 space-y-1 font-sans text-xs text-slate-500">
                        {edu.highlights.map((h, hIdx) => (
                          <li key={hIdx}>{h}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="text-right sm:shrink-0 font-mono text-xs space-y-1">
                      <div className="text-slate-800 font-bold">{edu.period}</div>
                      <div className="text-brand-600 font-bold bg-brand-50 px-2.5 py-0.5 rounded-full border border-brand-100/60 inline-block text-[11px]">
                        {edu.scoreName}: {edu.scoreValue}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 4. SYSTEMS DEVELOPMENT PORTFOLIO */}
            <div className="space-y-3">
              <h3 className="font-display font-extrabold text-sm uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1">
                Completed Engineering Workspaces
              </h3>

              <div className="space-y-4">
                {data.projects.map((proj) => (
                  <div key={proj.id} className="space-y-1.5">
                    <div className="flex flex-wrap justify-between items-baseline gap-1">
                      <div className="flex items-center space-x-1.5">
                        <span className="font-display font-bold text-slate-850 text-sm">
                          {proj.title}
                        </span>
                        <span className="text-[10px] font-mono text-slate-400 bg-slate-150 px-1.5 py-0.5 rounded">
                          {proj.technologies.slice(0, 3).join(", ")}
                        </span>
                      </div>
                      <a
                        href={proj.githubUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="font-mono text-[10px] text-brand-650 hover:underline"
                      >
                        github_repo://{proj.id}
                      </a>
                    </div>
                    <p className="font-sans text-xs text-slate-600 leading-relaxed">
                      {proj.longDescription || proj.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* 5. COGNITIVE SKILLS MATRIX */}
            <div className="space-y-3">
              <h3 className="font-display font-extrabold text-sm uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1">
                Core Development Competency
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-sans">
                <div className="space-y-1">
                  <span className="block font-bold text-slate-800 border-r border-slate-100 uppercase tracking-wider text-[10px] font-mono">Languages</span>
                  <span className="text-slate-600">C, C++ (Algorithms), Java, Python (PyTorch)</span>
                </div>
                <div className="space-y-1">
                  <span className="block font-bold text-slate-800 border-r border-slate-100 uppercase tracking-wider text-[10px] font-mono">Web Engines</span>
                  <span className="text-slate-600">HTML5, CSS3, JavaScript, React, TypeScript, Tailwind</span>
                </div>
                <div className="space-y-1">
                  <span className="block font-bold text-slate-800 uppercase tracking-wider text-[10px] font-mono">Databases & AI</span>
                  <span className="text-slate-600">SQL, SQLite, PostgreSQL, Machine Learning, Neural Networks</span>
                </div>
              </div>
            </div>

            {/* 6. CREDENTIAL CERTIFICATIONS */}
            <div className="space-y-3">
              <h3 className="font-display font-extrabold text-sm uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1">
                Professional Certifications & Accolades
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2 text-xs font-sans text-slate-600">
                {data.certifications.map((cert) => (
                  <div key={cert.id} className="flex items-center justify-between border-b border-slate-50 py-1">
                    <span className="font-bold text-slate-800">{cert.name}</span>
                    <span className="font-mono text-[10px] text-slate-400 shrink-0 select-none ml-2 bg-slate-50 border px-1.5 py-0.5 rounded">
                      {cert.issuer}
                    </span>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>

        {/* Dynamic CV Footer */}
        <div className="no-print bg-white px-6 py-4 border-t border-slate-200 text-center font-mono text-[10px] text-slate-400">
          Generated via Guest Node. Pressed Print directs output cleanly to standard A4 sheets.
        </div>

      </div>
    </div>
  );
}
