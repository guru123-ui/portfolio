import React from "react";
import { GraduationCap, Award, BookOpen, Target, Calendar, MapPin, ChevronRight } from "lucide-react";
import { PortfolioData } from "../types";

interface AboutProps {
  data: PortfolioData;
}

export default function About({ data }: AboutProps) {
  return (
    <section id="about" className="py-20 bg-white border-y border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            About Me
          </h2>
          <div className="w-12 h-1 bg-brand-600 mx-auto mt-3 rounded-full" />
          <p className="mt-4 font-sans text-base text-slate-600">
            A comprehensive overview of my current professional focus, research directions, and academic track record.
          </p>
        </div>

        {/* Contents Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Career Objective (Left Hand Column) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-brand-50/50 rounded-2xl p-6 sm:p-8 border border-brand-100 relative overflow-hidden shadow-sm">
              <div className="absolute top-0 right-0 w-32 h-32 bg-brand-100/30 rounded-full filter blur-xl opacity-70 pointer-events-none" />
              
              <div className="flex items-center space-x-3 mb-5">
                <div className="p-2.5 bg-brand-600 text-white rounded-xl">
                  <Target className="w-5 h-5" />
                </div>
                <h3 className="font-display text-lg font-bold text-slate-800">
                  Career Objective
                </h3>
              </div>
              
              <p className="font-sans text-base text-slate-700 leading-relaxed">
                {data.careerObjective}
              </p>

              <div className="mt-8 pt-6 border-t border-brand-100/80 space-y-3">
                <h4 className="font-display font-semibold text-xs text-brand-800 uppercase tracking-widest">
                  Key Research Interests
                </h4>
                <div className="flex flex-wrap gap-2">
                  {["System Algorithms", "Distributed DBs", "Reinforcement Learning", "Query Optimization", "APIs"].map((interest) => (
                    <span
                      key={interest}
                      className="px-3 py-1.5 bg-white text-slate-700 border border-slate-200/80 text-xs font-semibold rounded-lg shadow-sm"
                    >
                      {interest}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-5 bg-white border border-slate-100 rounded-xl text-center shadow-sm hover:shadow-md transition-shadow">
                <div className="text-3xl font-display font-extrabold text-brand-600">9.34</div>
                <div className="text-xs font-sans font-medium text-slate-500 mt-1 uppercase tracking-wider">Current B.E. CGPA</div>
              </div>
              <div className="p-5 bg-white border border-slate-100 rounded-xl text-center shadow-sm hover:shadow-md transition-shadow">
                <div className="text-3xl font-display font-extrabold text-brand-600">4+</div>
                <div className="text-xs font-sans font-medium text-slate-500 mt-1 uppercase tracking-wider">Major ML/CS Projects</div>
              </div>
            </div>
          </div>

          {/* Education Timeline (Right Hand Column) */}
          <div className="lg:col-span-7 space-y-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 bg-brand-50 text-brand-600 rounded-lg">
                <GraduationCap className="w-5 h-5" />
              </div>
              <h3 className="font-display text-xl font-bold text-slate-800">
                Educational Background
              </h3>
            </div>

            {/* Timeline wrapper */}
            <div className="relative pl-6 border-l-2 border-brand-100/80 space-y-12">
              {data.education.map((edu, idx) => (
                <div key={edu.id} className="relative group">
                  
                  {/* Bullet */}
                  <div className="absolute -left-[31px] top-1.5 bg-white p-1 rounded-full border-2 border-brand-500 transition-colors group-hover:bg-brand-600">
                    <div className="w-2.5 h-2.5 rounded-full bg-brand-600 group-hover:bg-white" />
                  </div>

                  {/* Date and Grade */}
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                    <div className="flex items-center space-x-1 text-xs font-semibold font-mono text-slate-500 bg-slate-50 border border-slate-200/50 px-2.5 py-1 rounded-md">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>{edu.period}</span>
                    </div>

                    <div className="flex items-center space-x-1.5 text-xs font-bold text-brand-600 bg-brand-100/50 px-3 py-1 rounded-full border border-brand-200/40">
                      <Award className="w-3.5 h-3.5 text-brand-500" />
                      <span>{edu.scoreName}: {edu.scoreValue}</span>
                    </div>
                  </div>

                  {/* Header info */}
                  <h4 className="font-display text-lg font-bold text-slate-900 group-hover:text-brand-600 transition-colors">
                    {edu.degree}
                  </h4>
                  <p className="font-sans text-sm font-semibold text-slate-700 flex items-center space-x-1 mt-0.5">
                    <BookOpen className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{edu.institution}</span>
                  </p>

                  {/* Highlights list */}
                  <ul className="mt-3.5 space-y-2">
                    {edu.highlights.map((highlight, hIdx) => (
                      <li key={hIdx} className="flex items-start text-xs sm:text-sm text-slate-600">
                        <ChevronRight className="w-4 h-4 text-brand-500 shrink-0 mr-1.5 mt-0.5" />
                        <span>{highlight}</span>
                      </li>
                    ))}
                  </ul>

                </div>
              ))}
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
