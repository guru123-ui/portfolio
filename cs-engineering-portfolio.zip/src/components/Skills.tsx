import React, { useState } from "react";
import * as LucideIcons from "lucide-react";
import { PortfolioData, Skill } from "../types";

interface SkillsProps {
  data: PortfolioData;
}

// Map string icon names to Lucide icons to prevent dynamic import compilation errors
const getSkillIcon = (iconName: string) => {
  switch (iconName) {
    case "Cpu":
      return <LucideIcons.Cpu className="w-5 h-5 text-brand-600" />;
    case "FileCode":
      return <LucideIcons.FileCode className="w-5 h-5 text-brand-600" />;
    case "Coffee":
      return <LucideIcons.Coffee className="w-5 h-5 text-brand-600" />;
    case "CodeXml":
    case "Code":
      return <LucideIcons.Code className="w-5 h-5 text-brand-600" />;
    case "Palette":
      return <LucideIcons.Palette className="w-5 h-5 text-brand-600" />;
    case "SquareTerminal":
      return <LucideIcons.SquareTerminal className="w-5 h-5 text-brand-600" />;
    case "Atom":
      return <LucideIcons.Atom className="w-5 h-5 text-brand-600" />;
    case "Database":
      return <LucideIcons.Database className="w-5 h-5 text-brand-600" />;
    case "BrainCircuit":
      return <LucideIcons.BrainCircuit className="w-5 h-5 text-brand-600" />;
    case "Workflow":
      return <LucideIcons.Workflow className="w-5 h-5 text-brand-600" />;
    default:
      return <LucideIcons.Code className="w-5 h-5 text-brand-600" />;
  }
};

type CategoryFilter = "All" | "Languages" | "Web Development" | "Databases & AI/ML";

export default function Skills({ data }: SkillsProps) {
  const [selectedCategory, setSelectedCategory] = useState<CategoryFilter>("All");
  const [selectedSkill, setSelectedSkill] = useState<Skill | null>(data.skills[3]); // Default to first skill or Python

  const categories: CategoryFilter[] = ["All", "Languages", "Web Development", "Databases & AI/ML"];

  const filteredSkills = selectedCategory === "All"
    ? data.skills
    : data.skills.filter(s => s.category === selectedCategory);

  return (
    <section id="skills" className="py-20 bg-slate-50 relative overflow-hidden tech-grid-dots">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            My Skill Set
          </h2>
          <div className="w-12 h-1 bg-brand-600 mx-auto mt-3 rounded-full" />
          <p className="mt-4 font-sans text-base text-slate-600">
            A comprehensive overview of my tech stack, categorized by technical focus. Click any skill card to inspect its real-world implementation logs.
          </p>
        </div>

        {/* Category Filters Carousel / Tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => {
                  setSelectedCategory(cat);
                  // Auto focus on the first skill of that new list
                  const firstOfCat = cat === "All" ? data.skills[3] : data.skills.find(s => s.category === cat);
                  if (firstOfCat) setSelectedSkill(firstOfCat);
                }}
                className={`px-4 sm:px-6 py-2.5 rounded-full text-xs sm:text-sm font-semibold font-sans transition-all shadow-sm ${
                  isActive
                    ? "bg-brand-600 text-white"
                    : "bg-white text-slate-600 hover:text-brand-600 hover:bg-slate-100 border border-slate-200/50"
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>

        {/* Unified Interactive Showcase Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Skills Grid List (Left 8 Columns) */}
          <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {filteredSkills.map((skill) => {
              const isFocused = selectedSkill?.name === skill.name;
              return (
                <div
                  key={skill.name}
                  onClick={() => setSelectedSkill(skill)}
                  className={`p-5 rounded-2xl border text-left cursor-pointer transition-all duration-300 relative overflow-hidden flex flex-col justify-between ${
                    isFocused
                      ? "bg-white border-brand-500 ring-2 ring-brand-500/10 shadow-md transform -translate-y-0.5"
                      : "bg-white border-slate-100 shadow-sm hover:border-slate-350 hover:shadow-md hover:-translate-y-0.5"
                  }`}
                >
                  <div className="space-y-3">
                    {/* Header */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`p-2 rounded-xl border ${isFocused ? "bg-brand-50 border-brand-100" : "bg-slate-50 border-slate-100"}`}>
                          {getSkillIcon(skill.icon)}
                        </div>
                        <h4 className="font-display font-bold text-slate-800 text-base">
                          {skill.name}
                        </h4>
                      </div>
                      <span className="text-xs font-mono font-bold text-brand-600 bg-brand-50 border border-brand-100 px-2 py-0.5 rounded-md">
                        {skill.level}%
                      </span>
                    </div>

                    {/* Progress slider bar */}
                    <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-brand-600 h-full rounded-full transition-all duration-500"
                        style={{ width: `${skill.level}%` }}
                      />
                    </div>
                  </div>

                  {/* Tiny footnote indicating interactivity */}
                  <div className="mt-4 flex items-center justify-between text-[11px] font-mono text-slate-400">
                    <span>Category: {skill.category}</span>
                    <span className="text-brand-500 hover:underline">Inspect spec &rarr;</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Interactive Inspection Terminal (Right 4 Columns) */}
          <div className="lg:col-span-4 flex">
            {selectedSkill ? (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 flex flex-col justify-between w-full h-full shadow-lg text-white">
                
                <div className="space-y-6">
                  {/* Fake macOS style window dots */}
                  <div className="flex items-center space-x-1.5">
                    <span className="w-3 h-3 rounded-full bg-[#ff5f56]" />
                    <span className="w-3 h-3 rounded-full bg-[#ffbd2e]" />
                    <span className="w-3 h-3 rounded-full bg-[#27c93f]" />
                    <span className="text-xs font-mono text-slate-500 ml-2">skill_diagnostics.sh</span>
                  </div>

                  {/* Header info */}
                  <div className="space-y-1 bg-slate-950/80 p-4 border border-slate-800/80 rounded-xl">
                    <div className="text-[11px] font-mono text-brand-400">TARGET_MODULE</div>
                    <div className="font-display text-xl font-bold flex items-center gap-2">
                      <span className="p-1.5 bg-slate-800 rounded-md">
                        {getSkillIcon(selectedSkill.icon)}
                      </span>
                      <span>{selectedSkill.name}</span>
                    </div>
                    <div className="text-xs font-mono text-slate-400 mt-1">
                      Proficiency Level: {selectedSkill.level}% (Expert / Intermediate)
                    </div>
                  </div>

                  {/* Applied details */}
                  <div className="space-y-2">
                    <span className="text-[11px] font-mono text-slate-400 uppercase tracking-widest block font-bold">
                      Applications & Implementation
                    </span>
                    <p className="font-sans text-sm text-slate-200 leading-relaxed bg-slate-950/40 p-4 border border-slate-850 rounded-xl">
                      {selectedSkill.details}
                    </p>
                  </div>
                </div>

                {/* Simulated System output code */}
                <div className="mt-8 pt-4 border-t border-slate-800 bg-slate-950/30 -mx-6 -mb-6 p-6 rounded-b-3xl font-mono text-left">
                  <div className="text-xs text-brand-300 flex items-center space-x-1">
                    <span className="text-green-500">$</span>
                    <span>check_capability --id="{selectedSkill.name.toLowerCase()}"</span>
                  </div>
                  <div className="text-[11px] text-slate-400 space-y-1 mt-2 font-mono">
                    <div>&gt; Loading library vectors... [SUCCESS]</div>
                    <div>&gt; Performance index metrics output clear.</div>
                    <div className="text-green-400 font-bold">&gt; Status: ROBUST_KNOWLEDGE</div>
                  </div>
                </div>

              </div>
            ) : (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 flex flex-col justify-center items-center w-full min-h-[300px] text-center shadow-lg text-white font-mono text-xs text-slate-500">
                Click a skill to run code logs
              </div>
            )}
          </div>

        </div>

      </div>
    </section>
  );
}
