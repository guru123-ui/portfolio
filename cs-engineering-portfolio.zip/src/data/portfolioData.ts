import { PortfolioData } from "../types";

export const portfolioData: PortfolioData = {
  ownerName: "Guru Prasath R",
  title: "Computer Science Engineering Student",
  subtitle: "Specializing in Full-Stack Systems & AI Workflows",
  introText: "I am a passionate Computer Science and Engineering student focused on building high-performance systems and exploring machine learning networks. Experienced in building algorithmic query modules, full-stack web applications, and predictive AI dashboards.",
  careerObjective: "A dedicated and analytical Computer Science Engineering undergraduate seeking a Software Engineering internship or entry-level role. Passionate about applying core algorithm design, data engineering, full-stack frameworks, and artificial intelligence models to implement robust, scalable, and impactful solutions.",
  avatarUrl: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=500&q=80",
  education: [
    {
      id: "edu-1",
      degree: "Bachelor of Engineering (B.E.) in Computer Science & Engineering",
      institution: "PSG College of Technology",
      period: "2023 - 2027",
      scoreName: "CGPA",
      scoreValue: "9.34 / 10.0",
      highlights: [
        "Specialized Coursework: Data Structures & Algorithms, Database Management Systems, Operating Systems, Computer Networks, Machine Learning",
        "Active Member of Association of Computer Science Engineers (ACSE)",
        "Top 5% of the Batch"
      ]
    },
    {
      id: "edu-2",
      degree: "Higher Secondary Certificate (HSC) - Computer Science Major",
      institution: "St. John's Matriculation Higher Secondary School",
      period: "2021 - 2023",
      scoreName: "Score",
      scoreValue: "96.4 %",
      highlights: [
        "Centum in Computer Science and Mathematics",
        "Lead coordinator for the Annual Science Fair",
        "Ranked school-wide #2 in Board Exams"
      ]
    }
  ],
  skills: [
    // Languages
    {
      name: "C",
      category: "Languages",
      icon: "Cpu",
      level: 85,
      details: "Used for system programming, hardware simulation, and academic memory allocation research."
    },
    {
      name: "C++",
      category: "Languages",
      icon: "FileCode",
      level: 90,
      details: "Primary language for Data Structures & Algorithms and competitive programming. Mastered memory mechanics."
    },
    {
      name: "Java",
      category: "Languages",
      icon: "Coffee",
      level: 88,
      details: "Used for enterprise-oriented object structures, multithreading, and Spring Boot backend creations."
    },
    {
      name: "Python",
      category: "Languages",
      icon: "CodeXml",
      level: 92,
      details: "Core language for scripting, machine learning modeling with PyTorch, and scraping pipelines."
    },
    // Web Technologies
    {
      name: "HTML5",
      category: "Web Development",
      icon: "Html5",
      level: 95,
      details: "Semantic structures, accessible markup patterns, and fluid document hierarchy."
    },
    {
      name: "CSS3 & Tailwind",
      category: "Web Development",
      icon: "Palette",
      level: 92,
      details: "Modern flex/grid layouts, keyframe transitions, and utility-first styling."
    },
    {
      name: "JavaScript (ES6+)",
      category: "Web Development",
      icon: "SquareTerminal",
      level: 90,
      details: "Asynchronous loops, DOM parsing, and event-driven browser processes."
    },
    {
      name: "React & TypeScript",
      category: "Web Development",
      icon: "Atom",
      level: 88,
      details: "Component architecture, responsive rendering hooks, and compile-time type structures."
    },
    // SQL, AI, ML
    {
      name: "SQL (PostgreSQL / MySQL)",
      category: "Databases & AI/ML",
      icon: "Database",
      level: 86,
      details: "Query planning, nested joins, B+ tree index optimizations, and normalization schemas."
    },
    {
      name: "Artificial Intelligence",
      category: "Databases & AI/ML",
      icon: "BrainCircuit",
      level: 84,
      details: "Informed heuristic searches, neural net configurations, and state-graph pathfindings."
    },
    {
      name: "Machine Learning (ML)",
      category: "Databases & AI/ML",
      icon: "Workflow",
      level: 85,
      details: "Regression, clustering algorithms, supervised classifications with Scikit-Learn pipelines."
    }
  ],
  projects: [
    {
      id: "proj-1",
      title: "IntelliRoute AI - Dynamic Traffic Control",
      description: "An AI-powered traffic forecasting and control system designed to dynamically reduce wait delays at key intersections.",
      longDescription: "Developed an intelligent, real-time traffic signal optimization suite using Python and neural networks. The system parses simulated surveillance video feeds to measure lane densities, then feeds queues into a deep reinforcement learning processor that minimizes average commuter wait times by 32% compared to static timers.",
      technologies: ["Python", "PyTorch", "OpenCV", "Flask", "Tailwind CSS"],
      githubUrl: "https://github.com/guru-prasath/intelliroute-ai",
      liveUrl: "#",
      demoDetails: {
        terminalLogs: [
          "Initializing IntelliRoute Engine...",
          "Checking PyTorch GPU Acceleration... [CUDA Enabled]",
          "Loading Pre-trained YOLOv8 Vehicle Weights...",
          "Establishing Live Feed IPC Handshake on ws://localhost:8080",
          "Intersection state: South [32 Cars, Speed 12km/h], North [14 Cars, Speed 45km/h]",
          "AI Decided: Extending GREEN light for South lane by 18 seconds.",
          "Feedback loop running. Target congestion reduced by 28%!"
        ],
        codeSnippet: `import torch
import cv2

class TraficAIController:
    def __init__(self, camera_feed):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.detector = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)
        self.feed = cv2.VideoCapture(camera_feed)
        
    def get_car_count(self):
        ret, frame = self.feed.read()
        if not ret: return 0
        results = self.detector(frame)
        # Filter for car, bus, truck classes (labels 2, 5, 7)
        vehicles = results.pred[0][(results.pred[0][:, 5] == 2) | (results.pred[0][:, 5] == 5)]
        return len(vehicles)
        
    def compute_optimal_green(self, density_map):
        # Reinforcement Q-network update
        inputs = torch.tensor(density_map, dtype=torch.float32).to(self.device)
        green_seconds = max(10, self.q_network(inputs).item() * 60)
        return int(green_seconds)`
      }
    },
    {
      id: "proj-2",
      title: "NovaBase - Custom SQL Query Engine",
      description: "A lightweight, custom transactional database execution engine written completely in C++ from the ground up.",
      longDescription: "A query runner featuring memory-mapped indexing structures, multi-join query execution planning, and an abstract syntax tree parsing pipeline. Created to deeply inspect how B+ tree structural locks and database storage blocks communicate directly with system buffers.",
      technologies: ["C++", "CMake", "GoogleTest", "SQL"],
      githubUrl: "https://github.com/guru-prasath/novabase-cpp",
      liveUrl: "#",
      demoDetails: {
        terminalLogs: [
          "Building NovaBase Query Engine with CMake...",
          "Compiling core/btree_indexer.cpp...",
          "Running Unit Tests... All 14 test scenarios passed [OK]",
          "Initializing interactive novabase REPL...",
          "novabase> CREATE TABLE students (id INT, name VARCHAR);",
          "Table 'students' created in database block 0x07AF",
          "novabase> SELECT name FROM students WHERE id = 101;",
          "Query Optimization Plan generated. Primary Index B-Tree matched. Index lock acquired in 0.04ms.",
          "Result: 1 Row Found. Name = 'Guru Prasath'"
        ],
        codeSnippet: `#include <iostream>
#include <vector>
#include <memory>

class BPlusNode {
public:
    bool is_leaf;
    std::vector<int> keys;
    std::vector<std::shared_ptr<BPlusNode>> children;
    
    BPlusNode(bool leaf) : is_leaf(leaf) {}
    
    void insert_non_full(int key) {
        int i = keys.size() - 1;
        if (is_leaf) {
            keys.push_back(0);
            while (i >= 0 && keys[i] > key) {
                keys[i + 1] = keys[i];
                i--;
            }
            keys[i + 1] = key;
        } else {
            while (i >= 0 && keys[i] > key) i--;
            i++;
            if (children[i]->keys.size() == 5) { // Max degree
                split_child(i, children[i]);
                if (keys[i] < key) i++;
            }
            children[i]->insert_non_full(key);
        }
    }
};`
      }
    },
    {
      id: "proj-3",
      title: "TaskSync - Team Coordination Workbench",
      description: "An enterprise style task management board featuring high-throughput WebSocket communication and charts.",
      longDescription: "A collaborative scrum portal supporting visual drag-and-drop workflow adjustments, historic activity auditing, automated task prioritisations, and charts. Solves concurrent database state writes by implementing optimistic locking mechanisms.",
      technologies: ["Java", "Spring Boot", "WebSockets", "React", "PostgreSQL"],
      githubUrl: "https://github.com/guru-prasath/tasksync",
      liveUrl: "#",
      demoDetails: {
        terminalLogs: [
          "Booting Spring Boot Application context...",
          "Connecting to database postgresql://localhost:5432/tasksync",
          "Liquibase migrations executed. 8 tables active.",
          "WebSocket message broker listening on port 8081",
          "[STOMP] Socket Handshake received from User 'Guru'",
          "[STOMP] Client Subscriptions active: /topic/board-101",
          "[EVENT] User 'Guru' moved Task #14 'Optimize Index' -> 'In Progress'",
          "[POSTGRES] Version lock matched. Broad-casting update state directly to all subscribers."
        ],
        codeSnippet: `@MessageMapping("/board/{boardId}/action")
@SendTo("/topic/board/{boardId}")
public BoardUpdateMessage handleBoardAction(@DestinationVariable Long boardId, 
                                             BoardActionPayload action,
                                             Principal principal) {
    logger.info("User {} performed action {} on board {}", principal.getName(), action.getType(), boardId);
    
    Task task = taskRepository.findById(action.getTaskId())
        .orElseThrow(() -> new ResourceNotFoundException("Task not found"));
        
    task.setStatus(action.getNewStatus());
    task.setLastModifiedBy(principal.getName());
    taskRepository.save(task); // Optimistic locking via @Version
    
    return new BoardUpdateMessage(boardId, task.getId(), task.getStatus(), principal.getName());
}`
      }
    },
    {
      id: "proj-4",
      title: "PhysiX - Interactive Browser Engine",
      description: "A customized 2D physics modeling framework rendering rigid bodies with customized restitution settings.",
      longDescription: "An interactive, math-driven visual playground showcasing circle-to-circle and polygon-to-polygon elastic collisions. Built completely using Vanilla Web Elements and HTML5 2D contexts, relying on vector mathematics to distribute rebound kinetic energy accurately.",
      technologies: ["JavaScript", "HTML5 Canvas", "Tailwind CSS", "Vite"],
      githubUrl: "https://github.com/guru-prasath/physix-engine",
      liveUrl: "#",
      demoDetails: {
        terminalLogs: [
          "Starting HTML5 Canvas Render Core...",
          "Setting physics frame cadence target to 60fps",
          "Rigid boundaries populated: Left [X=0], Right [X=1280]",
          "Spawning rigid materials: Steel, Wood, Rubber [Gravity = 9.81m/s²]",
          "Collision system loaded: Impulse Math solver active with dynamic friction.",
          "Ready! Click workspace to spawn a bouncing sphere."
        ],
        codeSnippet: `class Vector2D {
    constructor(x, y) { this.x = x; this.y = y; }
    add(v) { return new Vector2D(this.x + v.x, this.y + v.y); }
    subtract(v) { return new Vector2D(this.x - v.x, this.y - v.y); }
    multiply(n) { return new Vector2D(this.x * n, this.y * n); }
    dot(v) { return this.x * v.x + this.y * v.y; }
    magnitude() { return Math.sqrt(this.x * this.x + this.y * this.y); }
    normalize() {
        const mag = this.magnitude();
        return mag === 0 ? new Vector2D(0, 0) : new Vector2D(this.x / mag, this.y / mag);
    }
}

function resolveCollision(b1, b2, normal) {
    const relativeVelocity = b2.velocity.subtract(b1.velocity);
    const velAlongNormal = relativeVelocity.dot(normal);
    if (velAlongNormal > 0) return; // Moving away
    
    const e = Math.min(b1.restitution, b2.restitution); // Coefficient of resolution
    let j = -(1 + e) * velAlongNormal;
    j /= (1 / b1.mass) + (1 / b2.mass);
    
    const impulse = normal.multiply(j);
    b1.velocity = b1.velocity.subtract(impulse.multiply(1 / b1.mass));
    b2.velocity = b2.velocity.add(impulse.multiply(1 / b2.mass));
}`
      }
    }
  ],
  certifications: [
    {
      id: "cert-1",
      name: "Google Cloud Certified: Associate Cloud Engineer",
      issuer: "Google Cloud / Coursera",
      date: "Dec 2025",
      credentialId: "GCP-ACE-983011",
      verifyUrl: "https://coursera.org/verify/gcp-associate-cloud-engineer",
      badgeColor: "bg-blue-50 text-blue-700 border-blue-200"
    },
    {
      id: "cert-2",
      name: "AWS Certified Developer - Associate",
      issuer: "Amazon Web Services (AWS)",
      date: "Oct 2025",
      credentialId: "AWS-DVA-25081",
      verifyUrl: "https://aws.amazon.com/verification",
      badgeColor: "bg-emerald-50 text-emerald-700 border-emerald-200"
    },
    {
      id: "cert-3",
      name: "Deep Learning Specialization",
      issuer: "DeepLearning.AI / Coursera",
      date: "Aug 2025",
      credentialId: "DL-SPEC-DEEP32",
      verifyUrl: "https://coursera.org/verify/deep-learning",
      badgeColor: "bg-purple-50 text-purple-700 border-purple-200"
    },
    {
      id: "cert-4",
      name: "NPTEL National Certification: Data Structures & Algorithms",
      issuer: "IIT Madras / NPTEL (Elite + Silver Medal)",
      date: "May 2025",
      credentialId: "NPTEL25CS10928",
      verifyUrl: "https://nptel.ac.in/noc",
      badgeColor: "bg-amber-50 text-amber-700 border-amber-200"
    }
  ],
  contactInfo: {
    email: "rguruprasath29808@gmail.com",
    phone: "+91 98765 43210",
    location: "Coimbatore, Tamil Nadu, India",
    linkedin: "https://linkedin.com/in/guru-prasath-r",
    github: "https://github.com/guru-prasath-r"
  }
};
